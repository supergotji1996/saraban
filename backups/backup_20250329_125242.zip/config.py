import os
from flask_sqlalchemy import SQLAlchemy

class Config:
    # คีย์ลับสำหรับ Flask application
    SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key')
    
    # โฟลเดอร์สำหรับไฟล์ที่อัปโหลด
    UPLOAD_FOLDER = 'uploads'
    
    # การตั้งค่าแคช
    CACHE_TYPE = 'SimpleCache'
    CACHE_DEFAULT_TIMEOUT = 300  # 5 นาที
    
    # นามสกุลไฟล์ที่อนุญาตให้อัปโหลด
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png'}
    
    # ID ของ Google Sheets แต่ละประเภท
    SPREADSHEET_IDS = {
        'หนังสือส่ง': '1rGJPHTAe3lXsaBBPs1yz6P0-wguP26h0u9PQSWk25Ho',
        'บันทึกข้อความ': '159wqV2SGLwHHWHmugmQkj5oHMn5p1KIdgoSyuGZKFeg',
        'คำสั่ง': '1k6lgO3PpYqiTZjEYcwmgmnfftpXWp-oa3DTgMykib8o',
        'ประกาศ': '1tqhmPhmBJ-yKQcerGhiiGfgw3iiW0d4UXHyTN-PFlZA'
    }
    
    # ข้อมูลของแต่ละทะเบียน
    REGISTERS = {
        'หนังสือส่ง': {
            'sheet_name': 'ทะเบียนหนังสือส่ง 2568',
            'columns': ['ที่', 'ลงวันที่', 'จาก', 'ถึง', 'เรื่อง', 'การปฏิบัติ', 'ดาวน์โหลดหนังสือ'],
            'prefix': 'นภ72301/'
        },
        'บันทึกข้อความ': {
            'sheet_name': 'บันทึกข้อความ 2568',
            'columns': ['ที่', 'ลงวันที่', 'จาก', 'ถึง', 'เรื่อง', 'หมายเหตุ', 'ดาวน์โหลดหนังสือ'],
            'prefix': 'นภ72301/'
        },
        'คำสั่ง': {
            'sheet_name': 'ทะเบียนคำสั่ง 2568',
            'columns': ['เลขที่', 'เรื่อง', 'สั่ง ณ วันที่', 'การปฏิบัติ', 'หมายเหตุ', 'ดาวน์โหลดหนังสือ'],
            'prefix': ''
        },
        'ประกาศ': {
            'sheet_name': 'ทะเบียนประกาศ 2568',
            'columns': ['ลำดับที่', 'เรื่อง', 'ลงวันที่', 'วันที่มีผล', 'ส่วนราชการเจ้าของประกาศ', 'หมายเหตุ', 'ดาวน์โหลดหนังสือ'],
            'prefix': ''
        }
    }
    
    # ID ของ Sheet เก็บข้อมูลผู้ใช้
    USERS_SHEET_ID = '1YDfsBpyt-pFUqLK9AkSCOg-e78rq4OKnH9_0eG-prhs'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///document_register.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # การตั้งค่าอีเมล
    MAIL_SERVER = os.environ.get('MAIL_SERVER', 'smtp.example.com')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', '587'))
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS', 'true').lower() in ['true', 'on', '1']
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME', 'user@example.com')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD', 'password')
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER', 'noreply@example.com')
    
    # การตั้งค่า Telegram
    #TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '')
    #TELEGRAM_CHAT_ID = os.environ.get('TELEGRAM_CHAT_ID', '')
    
    # ระบบรีเซ็ตรหัสผ่าน
    PASSWORD_RESET_TOKEN_EXPIRY = 3600  # 1 ชั่วโมง
    PASSWORD_RESET_MAX_ATTEMPTS = 3  # จำนวนครั้งสูงสุดที่สามารถร้องขอรีเซ็ตรหัสผ่านใน 24 ชั่วโมง
    
    # การตั้งค่าความปลอดภัย
    MAX_LOGIN_ATTEMPTS = 5  # จำนวนครั้งสูงสุดที่สามารถล็อกอินผิดพลาดก่อนล็อคบัญชี
    ACCOUNT_LOCKOUT_TIME = 1800  # 30 นาที (ในหน่วยวินาที)
    
    # ผู้ดูแลระบบสามารถมองเห็นบันทึกย้อนหลังกี่วัน
    LOGS_RETENTION_DAYS = 30  # จำนวนวันที่เก็บบันทึกการใช้งานระบบ