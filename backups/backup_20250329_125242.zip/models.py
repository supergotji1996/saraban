from flask_login import UserMixin
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from flask import current_app
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

# กำหนดรหัสกอง/หน่วยงาน
DEPARTMENT_PREFIXES = {
    'สำนักปลัด': 'นภ72301/',
    'กองคลัง': 'นภ72302/',
    'กองช่าง': 'นภ72303/',
    'กองการศึกษาฯ': 'นภ72304/'
}

# คลาสฐานข้อมูล SQLite
class User(UserMixin, db.Model):
    """คลาส User สำหรับเก็บข้อมูลผู้ใช้งาน"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    display_name = db.Column(db.String(100))
    email = db.Column(db.String(100))
    role = db.Column(db.String(20), default='user')
    active = db.Column(db.Boolean, default=True)
    department = db.Column(db.String(100))
    allowed_registers = db.Column(db.String(255))

    # Relationships
    system_logs = db.relationship('SystemLog', backref='user', lazy=True)
    user_activities = db.relationship('UserActivity', backref='user', lazy=True)
    audit_trails = db.relationship('AuditTrail', backref='user', lazy=True)

    def get_department_prefix(self):
        """
        ดึงรหัสนำหน้าของกอง/หน่วยงาน
        
        Returns:
            str: รหัสนำหน้าของกอง/หน่วยงาน
        """
        return DEPARTMENT_PREFIXES.get(self.department, 'นภ72301/')
    
    @property
    def is_active(self):
        """
        ตรวจสอบสถานะการใช้งาน
        
        Returns:
            bool: True ถ้าบัญชีเปิดใช้งาน, False ถ้าปิดใช้งาน
        """
        return self.active

class SystemLog(db.Model):
    """คลาสเก็บบันทึกการใช้งานระบบ"""
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    username = db.Column(db.String(50), nullable=False)
    ip_address = db.Column(db.String(50))
    action_type = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)

class AuditTrail(db.Model):
    """คลาสเก็บประวัติการเปลี่ยนแปลงข้อมูล"""
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    username = db.Column(db.String(50), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    model = db.Column(db.String(50))
    record_id = db.Column(db.Integer)
    old_value = db.Column(db.Text)
    new_value = db.Column(db.Text)
    
class UserActivity(db.Model):
    """คลาสเก็บกิจกรรมการเข้าใช้งานระบบของผู้ใช้"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    username = db.Column(db.String(50), nullable=False)
    login_time = db.Column(db.DateTime, default=datetime.utcnow)
    logout_time = db.Column(db.DateTime, nullable=True)
    ip_address = db.Column(db.String(50))
    duration = db.Column(db.Integer, default=0)  # ในหน่วยวินาที
    
class UserManager:
    """
    คลาสสำหรับจัดการผู้ใช้งาน
    """
    def __init__(self, bcrypt=None):
        """
        กำหนดค่าเริ่มต้นของ UserManager
        
        Args:
            bcrypt (Bcrypt, optional): อินสแตนซ์ Bcrypt สำหรับเข้ารหัสรหัสผ่าน
        """
        self.bcrypt = bcrypt
    
    def _get_bcrypt(self):
        """
        ดึง bcrypt instance
        
        Returns:
            Bcrypt: อินสแตนซ์ Bcrypt
        """
        if self.bcrypt is None:
            from flask_bcrypt import Bcrypt
            return Bcrypt()
        return self.bcrypt
    
    def generate_password_hash(self, password):
        """
        เข้ารหัสรหัสผ่าน
        
        Args:
            password (str): รหัสผ่านที่ต้องการเข้ารหัส
        
        Returns:
            str: รหัสผ่านที่เข้ารหัสแล้ว
        """
        bcrypt = self._get_bcrypt()
        if isinstance(password, str):
            password = password.encode('utf-8')
        return bcrypt.generate_password_hash(password).decode('utf-8')
    
    def get_user(self, username):
        """
        ค้นหาผู้ใช้ด้วย username
        
        Args:
            username (str): ชื่อผู้ใช้ที่ต้องการค้นหา
        
        Returns:
            User: อ็อบเจกต์ User หรือ None ถ้าไม่พบ
        """
        # ตรวจสอบในฐานข้อมูล SQLite ก่อน
        from flask import current_app
        with current_app.app_context():
            # ตรวจสอบกรณีแอดมินแบบ hardcode
            if username == 'admin':
                user = User.query.filter_by(username='admin').first()
                if user:
                    return user
                
                # ถ้ายังไม่มีในฐานข้อมูล ให้สร้างใหม่
                admin_user = User(
                    username='admin',
                    password_hash=self.generate_password_hash('superadmin'),
                    display_name='ผู้ดูแลระบบ',
                    email='admin@example.com',
                    role='admin',
                    active=True
                )
                db.session.add(admin_user)
                db.session.commit()
                return admin_user
                
            # ตรวจสอบผู้ใช้ทั่วไป
            user = User.query.filter_by(username=username).first()
            if user:
                return user
                
            # ถ้าไม่พบในฐานข้อมูล ลองหาจาก Google Sheets
            try:
                from services.google_sheets import get_user
                user_dict = get_user(username)
                if user_dict:
                    # สร้างผู้ใช้ใหม่และบันทึกลงฐานข้อมูล
                    is_active = False
                    if isinstance(user_dict.get('active'), bool):
                        is_active = user_dict.get('active')
                    elif isinstance(user_dict.get('active'), str):
                        is_active = user_dict.get('active', '').lower() in ['true', '1', 'yes']
                    
                    # แปลงรายการทะเบียนที่อนุญาต
                    allowed_registers = ''
                    if user_dict.get('allowed_registers'):
                        if isinstance(user_dict.get('allowed_registers'), list):
                            allowed_registers = ','.join(user_dict.get('allowed_registers'))
                        else:
                            allowed_registers = user_dict.get('allowed_registers', '')
                    
                    # สร้างผู้ใช้ใหม่ในฐานข้อมูล
                    new_user = User(
                        username=user_dict.get('username', ''),
                        password_hash=user_dict.get('password', ''),
                        display_name=user_dict.get('display_name', ''),
                        email=user_dict.get('email', ''),
                        role=user_dict.get('role', 'user'),
                        active=is_active,
                        department=user_dict.get('department', ''),
                        allowed_registers=allowed_registers
                    )
                    db.session.add(new_user)
                    db.session.commit()
                    return new_user
                    
                return None
            except Exception as e:
                print(f"Error getting user {username}: {e}")
                return None
    
    def validate_login(self, username, password):
        """
        ตรวจสอบการล็อกอิน
        
        Args:
            username (str): ชื่อผู้ใช้
            password (str): รหัสผ่าน
        
        Returns:
            bool: True ถ้าล็อกอินสำเร็จ, False ถ้าไม่สำเร็จ
        """
        # ตรวจสอบ hardcoded admin
        if username == 'admin' and password == 'superadmin':
            return True
        
        try:
            user = self.get_user(username)
            if not user or not user.is_active:
                return False
            
            # ตรวจสอบรหัสผ่านแบบ plaintext
            if user.password_hash == password:
                return True
            
            # ถ้าไม่ตรงแบบ plaintext อาจจะเป็น hash แบบ bcrypt
            try:
                bcrypt = self._get_bcrypt()
                pw_hash = user.password_hash
                if isinstance(password, str):
                    password = password.encode('utf-8')
                if isinstance(pw_hash, str):
                    pw_hash = pw_hash.encode('utf-8')
                
                return bcrypt.check_password_hash(pw_hash, password)
            except:
                return False
        except Exception as e:
            print(f"Error validating login for {username}: {e}")
            return False

def add_user(self, username, password, display_name=None, email=None, 
                 role='user', active=True, department=None, allowed_registers=None):
        """
        เพิ่มผู้ใช้ใหม่
        
        Args:
            username (str): ชื่อผู้ใช้
            password (str): รหัสผ่าน
            display_name (str, optional): ชื่อที่แสดง
            email (str, optional): อีเมล
            role (str, optional): บทบาท ('user' หรือ 'admin')
            active (bool, optional): สถานะการใช้งาน
            department (str, optional): กอง/หน่วยงาน
            allowed_registers (list, optional): รายการทะเบียนที่อนุญาต
        
        Returns:
            bool: True ถ้าเพิ่มสำเร็จ, False ถ้าไม่สำเร็จ
        """
        try:
            # เก็บรหัสผ่านแบบเข้ารหัส
            password_hash = self.generate_password_hash(password)
            
            # แปลงรายการประเภทหนังสือเป็นสตริง
            allowed_registers_str = ','.join(allowed_registers) if allowed_registers else ''
            
            # เพิ่มผู้ใช้ใหม่ในฐานข้อมูล SQLite
            new_user = User(
                username=username,
                password_hash=password_hash,
                display_name=display_name or username,
                email=email or '',
                role=role,
                active=active,
                department=department or '',
                allowed_registers=allowed_registers_str
            )
            
            db.session.add(new_user)
            db.session.commit()
            
            # เพิ่มข้อมูลใน Google Sheets เพื่อความเข้ากันได้กับระบบเดิม
            try:
                from flask import current_app
                from services.google_sheets import get_sheets_client
                
                client = get_sheets_client()
                user_sheet_id = current_app.config['USERS_SHEET_ID']
                sheet = client.open_by_key(user_sheet_id).sheet1
                
                # เตรียมข้อมูลผู้ใช้
                new_user_data = [
                    username, 
                    password,  # เก็บรหัสผ่านแบบ plaintext สำหรับความเข้ากันได้
                    display_name or username, 
                    email or '', 
                    role, 
                    str(active),
                    allowed_registers_str,
                    department or ''
                ]
                
                # เพิ่มข้อมูลลงใน Sheet
                sheet.append_row(new_user_data)
            except Exception as e:
                print(f"Warning: Google Sheets update failed: {e}")
                # ไม่ถือเป็นข้อผิดพลาดร้ายแรง เนื่องจากข้อมูลถูกบันทึกในฐานข้อมูล SQLite แล้ว
            
            return True
        except Exception as e:
            print(f"Error adding user {username}: {e}")
            # ทำ rollback กรณีเกิดข้อผิดพลาด
            try:
                db.session.rollback()
            except:
                pass
            return False
    
def update_user(self, username, updates):
        """
        อัปเดตข้อมูลผู้ใช้
        
        Args:
            username (str): ชื่อผู้ใช้ที่ต้องการอัปเดต
            updates (dict): ข้อมูลที่ต้องการอัปเดต
        
        Returns:
            bool: True ถ้าอัปเดตสำเร็จ, False ถ้าไม่สำเร็จ
        """
        try:
            # อัปเดตข้อมูลผู้ใช้ในฐานข้อมูล SQLite
            user = User.query.filter_by(username=username).first()
            if not user:
                return False
            
            # อัปเดตข้อมูลแต่ละฟิลด์
            if 'display_name' in updates:
                user.display_name = updates['display_name']
            if 'email' in updates:
                user.email = updates['email']
            if 'role' in updates:
                user.role = updates['role']
            if 'active' in updates:
                user.active = updates['active']
            if 'department' in updates:
                user.department = updates['department']
            if 'allowed_registers' in updates:
                if isinstance(updates['allowed_registers'], list):
                    user.allowed_registers = ','.join(updates['allowed_registers'])
                else:
                    user.allowed_registers = updates['allowed_registers']
            if 'password' in updates:
                user.password_hash = self.generate_password_hash(updates['password'])
            
            db.session.commit()
            
            # อัปเดตข้อมูลใน Google Sheets เพื่อความเข้ากันได้กับระบบเดิม
            try:
                from flask import current_app
                from services.google_sheets import get_sheets_client
                
                client = get_sheets_client()
                user_sheet_id = current_app.config['USERS_SHEET_ID']
                sheet = client.open_by_key(user_sheet_id).sheet1
                
                # ค้นหาแถวของผู้ใช้
                cell = sheet.find(username)
                if cell:
                    row = cell.row
                    
                    # กำหนดลำดับคอลัมน์
                    columns = ['username', 'password', 'display_name', 'email', 'role', 'active', 'allowed_registers', 'department']
                    
                    # อัปเดตค่าในแต่ละคอลัมน์
                    for i, col in enumerate(columns):
                        if col in updates:
                            value = str(updates.get(col, ''))
                            sheet.update_cell(row, i+1, value)
            except Exception as e:
                print(f"Warning: Google Sheets update failed: {e}")
                # ไม่ถือเป็นข้อผิดพลาดร้ายแรง เนื่องจากข้อมูลถูกบันทึกในฐานข้อมูล SQLite แล้ว
            
            return True
        except Exception as e:
            print(f"Error updating user {username}: {e}")
            # ทำ rollback กรณีเกิดข้อผิดพลาด
            try:
                db.session.rollback()
            except:
                pass
            return False
    
def delete_user(self, username):
        """
        ลบผู้ใช้
        
        Args:
            username (str): ชื่อผู้ใช้ที่ต้องการลบ
        
        Returns:
            bool: True ถ้าลบสำเร็จ, False ถ้าไม่สำเร็จ
        """
        try:
            # ลบผู้ใช้จากฐานข้อมูล SQLite
            user = User.query.filter_by(username=username).first()
            if not user:
                return False
            
            db.session.delete(user)
            db.session.commit()
            
            # ลบผู้ใช้จาก Google Sheets เพื่อความเข้ากันได้กับระบบเดิม
            try:
                from flask import current_app
                from services.google_sheets import get_sheets_client
                
                client = get_sheets_client()
                user_sheet_id = current_app.config['USERS_SHEET_ID']
                sheet = client.open_by_key(user_sheet_id).sheet1
                
                # ค้นหาแถวของผู้ใช้
                cell = sheet.find(username)
                if cell:
                    # ลบแถว
                    sheet.delete_rows(cell.row)
            except Exception as e:
                print(f"Warning: Google Sheets delete failed: {e}")
                # ไม่ถือเป็นข้อผิดพลาดร้ายแรง เนื่องจากข้อมูลถูกลบในฐานข้อมูล SQLite แล้ว
            
            return True
        except Exception as e:
            print(f"Error deleting user {username}: {e}")
            # ทำ rollback กรณีเกิดข้อผิดพลาด
            try:
                db.session.rollback()
            except:
                pass
            return False